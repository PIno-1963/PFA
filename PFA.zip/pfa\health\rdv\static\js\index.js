const fname=document.getElementById('fname');
const femail=document.getElementById('femail');
const fsubject=document.getElementById('fsubject');
const fmessage=document.getElementById('fmessage');

const submit=document.getElementsByClassName('form-contact')[0];

submit.addEventListener('submit',(e)=>{
    e.preventDefault();
    console.log(fname.value);

    Email.send({
        Host : "smtp.elasticemail.com",
        Username : "hamzamoussaoui041@gmail.com",
        Password : "D3679546DFB74805E704A09BD1AA65A6FA49",
        To : 'healthcareinpt@gmail.com',
        From : "hamzamoussaoui041@gmail.com",
        Subject : fsubject.value,
        Body :"this email is sent by"+" "+fname.value+" "+"with email"+" "+femail.value+" "+"and message  : \n"+" "+
                 fmessage.value ,
    }).then(
      message => alert("email sent successfully")
    );
});
