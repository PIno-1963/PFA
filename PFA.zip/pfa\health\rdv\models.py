from django.db import models

# Create your models here.
class Appointment(models.Model):
    name = models.CharField(max_length=50 )
    email = models.EmailField()
    app_date = models.DateField()
    phone = models.CharField(max_length=13 , default='+212')
    age = models.CharField(max_length=10, choices=(('minor','Below 18'),('adult','18-50'),('old','above 50')))
    service = models.CharField(max_length= 15, choices = (('ORL','ORL'),('Card','Cardiology'),('Rad','Radiology'),('Phys','Physical therapy')))
    msg = models.TextField()
    time = models.CharField(max_length = 15 , choices = (("Matin" , '8:00 - 11:00'),('Midi','11:00 - 13:30'),('Après-midi','15:00 - 18:00')) )


    