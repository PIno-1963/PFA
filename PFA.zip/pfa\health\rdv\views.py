from django.shortcuts import render
from .models import Appointment
from datetime import datetime
from django.core.mail import send_mail
# Create your views here.
def busy(date , srvc) : 
    is_busy = [False ,False , False]
    if len(Appointment.objects.filter(service = srvc).filter(app_date = date ).filter(time = 'Matin'))> 11:
        is_busy[0] = True
    elif len(Appointment.objects.filter(service = srvc).filter(app_date = date ).filter(time = 'Midi'))> 11:
        is_busy[1] = True
    elif len(Appointment.objects.filter(service = srvc).filter(app_date = date ).filter(time = 'Après-midi'))> 11:
        is_busy[2] = True
    return is_busy
        
        

def home(request):
    if request.method == "POST":
        
        appt = Appointment()
        appt.name = request.POST['name']
        appt.email = request.POST['email']
        appt.app_date = request.POST['appointment_date']
        appt.phone = request.POST['phone']
        appt.time = request.POST['time']
        appt.age = request.POST['age']
        appt.service = request.POST['service']
        appt.msg = request.POST['message']
        [busy1 , busy2 , busy3] = busy(appt.app_date , appt.service)
        #email 
        subject = 'New Appointment'
        message = f"Bonjour M/Mme {appt.name},\nVotre rendez-vous est bien confirmé le {appt.app_date} {appt.time}.\nPour toute question ou modification de rendez-vous contactez-nous au 0612839131.\nCordialement, "
        from_email = "tachibox.omar@gmail.com"
        recipient_list = [f"{appt.email}"]  # Add email addresses of recipients
        
        send_mail(subject, message, from_email, recipient_list)
        
        context = {'busy1' : busy1 ,'busy2' : busy2 , 'busy3' : busy3}

                

            
             

        
        appt.save()
    return render(request , 'index.html',context)
